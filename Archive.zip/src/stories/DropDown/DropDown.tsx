import React, { useState } from 'react';
import { DropdownProps } from './DropDown.types';
import styled , {css} from 'styled-components';

const StyledSelect = styled.select<{$disabled?:boolean}>`
  padding: 8px 16px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 4px;
  background-color: #fff;
  cursor: pointer;
  ${props =>
    props.$disabled && 
    css`
    background-color:gray;
    opacity: 0.6;
    cursor: not-allowed;
    `
    }
`;

function Dropdown({ options, placeholder, onChange, disabled }: DropdownProps ){
  const [selectedOption, setSelectedOption] = useState<string | undefined>(undefined);

  const handleOptionChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedValue = event.target.value;
    setSelectedOption(selectedValue);
    onChange(selectedValue);
  };

  return (
    <StyledSelect $disabled={disabled} value={selectedOption} onChange={handleOptionChange}>
      {placeholder && <option value="">{placeholder}</option>}
      {options.map((option, index) => (
        <option key={index} value={option}>
          {option}
        </option>
      ))}
    </StyledSelect>
  );
};

export default Dropdown;
