export interface DropdownProps {
    options: string[];
    placeholder?: string;
    disabled:boolean;
    onChange: (selectedOption: string) => void;
  }
  