import React from 'react';
import { Meta, Story } from '@storybook/react';
import Dropdown from './DropDown.tsx';
import { DropdownProps } from './DropDown.types';

export default {
  title: 'Dropdown',
  component: Dropdown,
} as Meta;

const Template: Story<DropdownProps> = (args) => <Dropdown {...args} />;

export const Default = Template.bind({});
Default.args = {
  options: ['Option 1', 'Option 2', 'Option 3'],
  placeholder: 'Select an option',
  disabled:false,
  onChange: (selectedOption: string) => console.log('Selected option:', selectedOption),
};
