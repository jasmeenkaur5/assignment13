import React from 'react';
import { CardProps } from './Card.types';
import styled , {css} from 'styled-components';

const CardContainer = styled.div<{$border?:boolean, $largeMargin?: boolean, $DarkBackground?:boolean}>`
background-color: #ffffff;
border-radius: 8px;
box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
padding: 20px;
margin:10px;

${props =>
  props.$border && 
  css`
  border:2px solid #387ADF;
  `
  }
  ${props =>
    props.$largeMargin && 
    css`
    margin:30px;
    `
    }
    ${props =>
      props.$DarkBackground && 
      css`
      background-color: #387ADF;
      color:white;
      `
      }
`;
const Container = styled.div<{}>`
display: flex;
flex-wrap: wrap;
`;
function Card({ title, content, border,largeMargin, DarkBackground }: CardProps) {
  return (
    <Container>
    <CardContainer className="card" $border={border} $largeMargin={largeMargin} $DarkBackground={DarkBackground}>
      <h2>{title}</h2>
      <p>{content}</p>
    </CardContainer>
    <CardContainer className="card" $border={border} $largeMargin={largeMargin} $DarkBackground={DarkBackground}>
      <h2>{title}</h2>
      <p>{content}</p>
    </CardContainer>
    <CardContainer className="card" $border={border} $largeMargin={largeMargin} $DarkBackground={DarkBackground}>
      <h2>{title}</h2>
      <p>{content}</p>
    </CardContainer>
    <CardContainer className="card" $border={border} $largeMargin={largeMargin} $DarkBackground={DarkBackground}>
      <h2>{title}</h2>
      <p>{content}</p>
    </CardContainer>
    <CardContainer className="card" $border={border} $largeMargin={largeMargin} $DarkBackground={DarkBackground}>
      <h2>{title}</h2>
      <p>{content}</p>
    </CardContainer>
    </Container>
  );
};

export default Card;
