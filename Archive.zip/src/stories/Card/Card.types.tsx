import { BooleanValue } from "@storybook/blocks";

export interface CardProps {
    title: string;
    content: string;
    border: boolean;
    largeMargin:boolean;
    DarkBackground:boolean
  }
  