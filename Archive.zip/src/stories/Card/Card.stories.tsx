import React from 'react';
import { Meta, Story } from '@storybook/react';
import Card from './Card.tsx';
import { CardProps } from './Card.types.tsx';

export default {
  title: 'Card',
  component: Card,
} as Meta;

const Template: Story<CardProps> = (args) => <Card {...args} />;

export const Default = Template.bind({});
Default.args = {
  title: 'Sample Card',
  content: 'This is a sample card content.',
  border: true,
  largeMargin:false,
  DarkBackground:false

};
