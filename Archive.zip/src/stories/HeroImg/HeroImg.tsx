import React from 'react';
import { HeroImgProps } from './HeroImg.types';
import styled from 'styled-components';

const Image = styled.img<HeroImgProps>`
  width: ${(props) => props.width || '100%'};
  height: ${(props) => props.height || 'auto'};
`;

const HeroImg: React.FC<HeroImgProps> = ({ src, alt, width, height }) => {
  return <Image src={src} alt={alt} width={width} height={height} />;
};

export default HeroImg;
