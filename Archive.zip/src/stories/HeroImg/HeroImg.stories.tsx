import React from 'react';
import { Meta, Story } from '@storybook/react';
import HeroImg from './HeroImg.tsx';
import { HeroImgProps } from './HeroImg.types';

export default {
  title: 'HeroImg',
  component: HeroImg,
} as Meta;

const Template: Story<HeroImgProps> = (args) => <HeroImg {...args} />;

export const Default = Template.bind({});
Default.args = {
  src: 'https://plus.unsplash.com/premium_photo-1679822641172-d75e65b32dae?q=80&w=3540&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  alt: 'Hero Image',
};
