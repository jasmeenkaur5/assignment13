import React from "react";
import { ButtonProps } from "./button.types";
import { useState } from 'react';
import styled , {css} from "styled-components";

const StyledButton = styled.button<{$primary?: boolean, $big?: boolean, $disabled?:boolean}>`
  background-color: transparent;
  color: #387ADF;
  border-radius: 20px;
  border: 1px solid #387ADF;
  padding: 10px 20px;
  ${props =>
  props.$primary && 
  css`
  background-color:#387ADF;
  color:white;
  `
  }

  ${props =>
    props.$big && 
    css`
    padding: 20px 30px;
    `
    }

    ${props =>
      props.$disabled && 
      css`
      background-color:gray;
      opacity: 0.6;
      cursor: not-allowed;
      `
      }
`;
function Button({ primary,isBig, label, onClick, disabled }: ButtonProps) {
  

  return (
    <StyledButton $primary={primary} $big={isBig} $disabled={disabled}>
      {label}
    </StyledButton>
  );
}

export default Button ;
