export interface ButtonProps {
    label: string;
    primary:boolean;
    isBig:boolean;
    disabled:boolean;
    onClick?: () => void;
  }