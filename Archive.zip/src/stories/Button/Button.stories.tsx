import React from 'react';
import { Meta, Story } from '@storybook/react';
import  { ButtonProps } from './button.types';
import { useState } from 'react';
import Button from './Button.tsx';

export default {
  title: 'Button',
  component: Button,
  argTypes: {
    onClick: { action: 'clicked' }, // Mocking onClick event for demonstration
  },
} as Meta;

const Template: Story<ButtonProps> = (args) => <Button {...args} />;

export const Primary = Template.bind({});
Primary.args = {
  label: 'Primary Button',
  primary:true,
  isBig:false,
  disabled:false
};

