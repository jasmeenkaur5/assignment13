import React from "react";
import { LabelProps } from "./Label.types";


function Label({ label, color,fontSize, onClick }: LabelProps) {
    const style = {
      color: color,
      fontSize,
    };
  
    return (
      <label onClick={onClick} style={style} >
        {label}
      </label>
    );
  }

  export default Label;