export interface LabelProps {
    label: string;
    color?: string;
    onClick?: () => void;
    fontSize:string
  }