import React from 'react';
import { Meta, Story } from '@storybook/react';
import  { LabelProps } from './Label.types';
import { useState } from 'react';
import Label from "./Label.tsx";


export default {
  title: 'Label',
  component: Label,
  argTypes: {
    onClick: { action: 'clicked' }, 
  },
} as Meta;

const Template: Story<LabelProps> = (args) => <Label {...args} />;

export const Primary = Template.bind({});
Primary.args = {
  label: 'Primary Label',
  color:"black",
  fontSize:"20px"
};

export const Secondary = Template.bind({});
Secondary.args = {
  label: 'Secondary Label',
  color: 'gray',
  fontSize:"15px"
};
