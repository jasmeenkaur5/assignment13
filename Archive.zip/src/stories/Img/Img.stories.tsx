import React from 'react';
import { Meta, Story } from '@storybook/react';
import Image from './Img.tsx';
import { ImageProps } from './Img.types.tsx';

export default {
  title: 'Image',
  component: Image,
} as Meta;

const Template: Story<ImageProps> = (args) => <Image {...args} />;

export const Default = Template.bind({});
Default.args = {
  src: 'https://images.unsplash.com/photo-1682686578289-cf9c8c472c9b?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  alt: 'Placeholder Image',
  width:"500px",
  height:"500px"
};
