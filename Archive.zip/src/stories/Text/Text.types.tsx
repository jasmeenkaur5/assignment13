export interface TextProps {
    label: string;
    color?: string;
    onClick?: () => void;
    fontSize:string
  }