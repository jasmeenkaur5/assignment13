import React from 'react';
import { Meta, Story } from '@storybook/react';
import  { TextProps } from './Text.types.tsx';
import { useState } from 'react';

function Text({ label, color,fontSize, onClick }: TextProps) {
    const style = {
      color: color,
      fontSize,
    };
  
    return (
      <p onClick={onClick} style={style} >
        {label}
      </p>
    );
  }

export default {
  title: 'Text',
  component: Text,
  argTypes: {
    onClick: { action: 'clicked' }, 
  },
} as Meta;

const Template: Story<TextProps> = (args) => <Text {...args} />;

export const Primary = Template.bind({});
Primary.args = {
  label: 'Primary Text',
  color:"black",
  fontSize:"20px"
};

export const Secondary = Template.bind({});
Secondary.args = {
  label: 'Secondary Secondary',
  color: 'gray',
  fontSize:"15px"
};
