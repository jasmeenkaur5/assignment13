import React from 'react';
import { Meta, Story } from '@storybook/react';
import { TableProps } from './Table.types';
import Table from "./Table.tsx";

export default {
  title: 'Table',
  component: Table,
} as Meta;

const Template: Story<TableProps> = (args) => <Table {...args} />;

export const Default = Template.bind({});
Default.args = {
  headers: ['Header 1', 'Header 2', 'Header 3'],
  rows: [
    ['Row 1 Cell 1', 'Row 1 Cell 2', 'Row 1 Cell 3'],
    ['Row 2 Cell 1', 'Row 2 Cell 2', 'Row 2 Cell 3'],
    ['Row 3 Cell 1', 'Row 3 Cell 2', 'Row 3 Cell 3'],
  ],
  colSpacing: 10,
  cellColors: "white", 
  borderColor: "#387ADF", 
  borderWidth: 20,
};
