import React from "react";
import { TableProps } from "./Table.types";
function Table({ headers, rows, colSpacing = 10, cellColors, borderColor = 'black', borderWidth = 1 }: TableProps) {
    const tableStyle = {
      border: `${borderWidth}px solid ${borderColor}`,
    };
  
    const cellStyle = {
      padding: `${colSpacing / 2}px ${colSpacing}px`,
    };
  
    return (
      <table style={tableStyle}>
        <thead>
          <tr>
            {headers.map((header, index) => (
              <th key={index} style={cellStyle}>{header}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, rowIndex) => (
            <tr key={rowIndex}>
              {row.map((cell, cellIndex) => (
                <td key={cellIndex} style={{ ...cellStyle, backgroundColor: cellColors }}>{cell}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    );
  }

  export default Table;