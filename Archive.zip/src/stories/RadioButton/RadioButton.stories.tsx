import React from 'react';
import { Meta, Story } from '@storybook/react';
import RadioButton from './RadioButton.tsx';
import { RadioButtonProps } from './RadioButton.types';

export default {
  title: 'RadioButton',
  component: RadioButton,
} as Meta;

const Template: Story<RadioButtonProps> = (args) => <RadioButton {...args} />;

export const Default = Template.bind({});
Default.args = {
  options: [
    { label: 'Option 1', value: 'option1' },
    { label: 'Option 2', value: 'option2' },
    { label: 'Option 3', value: 'option3' },
  ],
  onChange: (selectedValue: string) => console.log('Selected value:', selectedValue),
  disabled:false
};
