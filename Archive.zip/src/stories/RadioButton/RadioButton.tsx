import React, { useState } from 'react';
import { RadioButtonProps} from './RadioButton.types';
import styled, {css} from 'styled-components';

const RadioInput = styled.input<{$disabled?:boolean}>`
  margin-right: 4px;
  ${props =>
    props.$disabled && 
    css`
    background-color:gray;
    opacity: 0.6;
    cursor: not-allowed;
    `
    } 
`;

const RadioLabel = styled.label`
  display: block; 
`;

function RadioButton({ options, onChange,disabled }: RadioButtonProps) {
  const [selectedOption, setSelectedOption] = useState<string | undefined>(undefined);

  const handleOptionChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedValue = event.target.value;
    setSelectedOption(selectedValue);
    onChange(selectedValue);
  };

  return (
    <div>
      {options.map((option) => (
        <RadioLabel key={option.value}>
          <RadioInput
            $disabled={disabled}
            type="radio"
            value={option.value}
            checked={selectedOption === option.value}
            onChange={handleOptionChange}
          />
          {option.label}
        </RadioLabel>
      ))}
    </div>
  );
};

export default RadioButton;
