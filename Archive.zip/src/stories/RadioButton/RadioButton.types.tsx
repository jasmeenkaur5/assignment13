export interface RadioButtonProps {
    options: { label: string; value: string }[];
    onChange: (selectedValue: string) => void;
    disabled:boolean
  }